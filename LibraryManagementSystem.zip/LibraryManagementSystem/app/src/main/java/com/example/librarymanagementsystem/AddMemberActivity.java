package com.example.librarymanagementsystem;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddMemberActivity extends AppCompatActivity {

    EditText edtMemberId, edtMemberName, edtMemberAddress, edtMemberPhone, edtUnpaidDues;
    Button btnAddMember;

    DatabaseHelper databaseHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_member);

        edtMemberId = findViewById(R.id.edtMemberId);
        edtMemberName = findViewById(R.id.edtMemberName);
        edtMemberAddress = findViewById(R.id.edtMemberAddress);
        edtMemberPhone = findViewById(R.id.edtMemberPhone);
        edtUnpaidDues = findViewById(R.id.edtUnpaidDues);

        btnAddMember = findViewById(R.id.btnAddMember);

        databaseHelper = new DatabaseHelper(this);

        btnAddMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMember();
            }
        });
    }

    private void addMember() {

        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        String memberId = edtMemberId.getText().toString().trim();
        String memberName = edtMemberName.getText().toString().trim();
        String address = edtMemberAddress.getText().toString().trim();
        String phone = edtMemberPhone.getText().toString().trim();
        String dues = edtUnpaidDues.getText().toString().trim();


        if (memberId.isEmpty() || memberName.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (address.isEmpty()) {
            // If member address is empty, set it to a default value or handle it as needed
            address = "Unknown";
        }

        if (phone.isEmpty()) {
            // If member phone is empty, set it to a default value or handle it as needed
            phone = "Unknown";
        }

        double unpaidDues = 0;
        if (!dues.isEmpty()) {
            unpaidDues = Double.parseDouble(dues);
        }


        boolean isInserted = databaseHelper.addMember(memberId, memberName, address, phone, unpaidDues);

        if (isInserted) {
            Toast.makeText(this, "Member added successfully!", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to add member!", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        edtMemberId.setText("");
        edtMemberName.setText("");
        edtMemberAddress.setText("");
        edtMemberPhone.setText("");
        edtUnpaidDues.setText("");
    }
}
