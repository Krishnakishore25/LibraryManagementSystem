package com.example.librarymanagementsystem;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddBookActivity extends AppCompatActivity {

    EditText edtBookId, edtTitle, edtPublisherName, edtAuthorName, edtBranchId, edtAccessNo;
    Button btnAddBook;

    DatabaseHelper databaseHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        edtBookId = findViewById(R.id.edtBookId);
        edtTitle = findViewById(R.id.edtTitle);
        edtPublisherName = findViewById(R.id.edtPublisherName);
        edtAuthorName = findViewById(R.id.edtAuthorName);
        edtBranchId = findViewById(R.id.edtBranchId);
        edtAccessNo = findViewById(R.id.edtAccessNo);

        btnAddBook = findViewById(R.id.btnAddBook);

        databaseHelper = new DatabaseHelper(this);

        btnAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBook();
            }
        });
    }

    private void addBook() {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        String bookId = edtBookId.getText().toString().trim();
        String title = edtTitle.getText().toString().trim();
        String publisherName = edtPublisherName.getText().toString().trim();
        String authorName = edtAuthorName.getText().toString().trim();
        String branchId = edtBranchId.getText().toString().trim();
        String accessNo = edtAccessNo.getText().toString().trim();

        ContentValues valuesBook = new ContentValues();
        valuesBook.put("BOOK_ID", bookId);
        valuesBook.put("TITLE", title);
        valuesBook.put("PUBLISHER_NAME", publisherName);

        ContentValues valuesAuthor = new ContentValues();
        valuesAuthor.put("BOOK_ID", bookId);
        valuesAuthor.put("AUTHOR_NAME", authorName);

        ContentValues valuesCopy = new ContentValues();
        valuesCopy.put("BOOK_ID", bookId);
        valuesCopy.put("BRANCH_ID", branchId);
        valuesCopy.put("ACCESS_NO", accessNo);

        long bookResult = db.insert("Book", null, valuesBook);
        long authorResult = db.insert("Book_Author", null, valuesAuthor);
        long copyResult = db.insert("Book_Copy", null, valuesCopy);

        if (bookId.isEmpty() || title.isEmpty() || publisherName.isEmpty() || authorName.isEmpty() || branchId.isEmpty() || accessNo.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (bookResult != -1 && authorResult != -1 && copyResult != -1) {
            Toast.makeText(this, "Book added successfully!", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to add book!", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }

    private void clearFields() {
        edtBookId.setText("");
        edtTitle.setText("");
        edtPublisherName.setText("");
        edtAuthorName.setText("");
        edtBranchId.setText("");
        edtAccessNo.setText("");
    }
}
