package com.example.librarymanagementsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GiveLoanActivity extends AppCompatActivity {

    EditText edtBookId, edtBranchId, edtMemberId;
    Button btnGiveLoan;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_loan);

        edtBookId = findViewById(R.id.edtBookId);
        edtBranchId = findViewById(R.id.edtBranchId);
        edtMemberId = findViewById(R.id.edtMemberId);
        btnGiveLoan = findViewById(R.id.btnGiveLoan);

        databaseHelper = new DatabaseHelper(this);

        btnGiveLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                giveLoan();
            }
        });
    }

    private void giveLoan() {
        String bookId = edtBookId.getText().toString().trim();
        String branchId = edtBranchId.getText().toString().trim();
        String memberId = edtMemberId.getText().toString().trim();

        if (!bookId.isEmpty() && !branchId.isEmpty() && !memberId.isEmpty()) {
            if (databaseHelper.isBookAvailable(bookId, branchId)) {
                databaseHelper.giveLoan(bookId, branchId, memberId);
                Toast.makeText(this, "Loan given successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Book not available in this branch!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
        }
    }
}
