package com.example.librarymanagementsystem;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddBranchActivity extends AppCompatActivity {

    EditText edtBranchId, edtBranchName, edtBranchAddress;
    Button btnAddBranch;

    DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_branch);

        edtBranchId = findViewById(R.id.edtBranchId);
        edtBranchName = findViewById(R.id.edtBranchName);
        edtBranchAddress = findViewById(R.id.edtBranchAddress);

        btnAddBranch = findViewById(R.id.btnAddBranch);

        databaseHelper = new DatabaseHelper(this);

        btnAddBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBranch();
            }
        });
    }

    private void addBranch() {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        String branchId = edtBranchId.getText().toString().trim();
        String branchName = edtBranchName.getText().toString().trim();
        String branchAddress = edtBranchAddress.getText().toString().trim();

        ContentValues valuesBranch = new ContentValues();
        valuesBranch.put("BRANCH_ID",branchId);
        valuesBranch.put("BRANCH_NAME",branchName);
        valuesBranch.put("ADDRESS",branchAddress);

        long branchResult = db.insert("Branch",null,valuesBranch);

        Log.d("AddBranchActivity","Branch ID: " + branchId);

        if (branchId.isEmpty() || branchName.isEmpty() || branchAddress.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }


        if (branchResult != -1) {
            Toast.makeText(this, "Branch added successfully!", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to add branch!", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }

    private void clearFields() {
        edtBranchId.setText("");
        edtBranchName.setText("");
        edtBranchAddress.setText("");
    }
}
