package com.example.librarymanagementsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAddBook = findViewById(R.id.btnAddBook);
        Button btnAddPublisher = findViewById(R.id.btnAddPublisher);
        Button btnAddBranch = findViewById(R.id.btnAddBranch);
        Button btnAddMember = findViewById(R.id.btnAddMember);
        Button btnLendBook = findViewById(R.id.btnLendBook);
        Button btnReturnBook = findViewById(R.id.btnReturnBook);

        btnAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddBookActivity.class));
            }
        });

        btnAddPublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddPublisherActivity.class));
            }
        });

        btnAddBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddBranchActivity.class));
            }
        });

        btnAddMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(MainActivity.this, AddMemberActivity.class));
            }
        });

        btnLendBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(MainActivity.this, GiveLoanActivity.class));
            }
        });

        btnReturnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(MainActivity.this, SearchBookActivity.class));
            }
        });
    }
}