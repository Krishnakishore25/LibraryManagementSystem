package com.example.librarymanagementsystem;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SearchBookActivity extends AppCompatActivity {

    EditText edtSearchBookId;
    Button btnSearchBook;
    TextView txtBookDetails;

    DatabaseHelper databaseHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_book);

        edtSearchBookId = findViewById(R.id.edtSearchBookId);
        btnSearchBook = findViewById(R.id.btnSearchBook);
        txtBookDetails = findViewById(R.id.txtBookDetails);

        databaseHelper = new DatabaseHelper(this);

        btnSearchBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchBook();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void searchBook() {
        String bookId = edtSearchBookId.getText().toString().trim();

        if (!bookId.isEmpty()) {
            Book book = databaseHelper.getBookById(bookId);
            if (book != null) {
                txtBookDetails.setText("Book found");
            } else {
                txtBookDetails.setText("Book not found");
            }
        } else {
            Toast.makeText(this, "Please enter book ID", Toast.LENGTH_SHORT).show();
        }
    }

    class Book {
    }
}
