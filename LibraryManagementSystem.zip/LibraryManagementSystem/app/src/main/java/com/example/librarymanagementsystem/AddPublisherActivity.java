package com.example.librarymanagementsystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.appcompat.app.AppCompatActivity;

public class AddPublisherActivity extends AppCompatActivity {

    EditText edtPublisherName, edtAddress, edtPhone;
    Button btnAddPublisher;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_publisher);

        edtPublisherName = findViewById(R.id.edtPublisherName);
        edtAddress = findViewById(R.id.edtAddress);
        edtPhone = findViewById(R.id.edtPhone);

        btnAddPublisher = findViewById(R.id.btnAddPublisher);

        databaseHelper = new DatabaseHelper(this);

        btnAddPublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPublisher();
            }
        });
    }

    private void addPublisher() {
        String publisherName = edtPublisherName.getText().toString().trim();
        String address = edtAddress.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();

        if (publisherName.isEmpty() || address.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isInserted = databaseHelper.addPublisher(publisherName, address, phone);

        if (isInserted) {
            Toast.makeText(this, "Publisher added successfully!", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to add publisher!", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        edtPublisherName.setText("");
        edtAddress.setText("");
        edtPhone.setText("");
    }
}
