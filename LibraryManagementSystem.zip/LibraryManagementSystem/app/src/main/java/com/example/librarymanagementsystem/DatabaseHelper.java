package com.example.librarymanagementsystem;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper<SimpleDateFormat> extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "library.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createBookTable = "CREATE TABLE Book( " +
                "BOOK_ID VARCHAR(13), " +
                "TITLE VARCHAR(30), " +
                "PUBLISHER_NAME VARCHAR(20), " +
                "PRIMARY KEY (BOOK_ID));";

        String createPublisherTable = "CREATE TABLE Publisher( " +
                "NAME VARCHAR(20), " +
                "ADDRESS VARCHAR(30), " +
                "PHONE VARCHAR(10), " +
                "PRIMARY KEY (NAME));";

        String createBookAuthorTable = "CREATE TABLE Book_Author( " +
                "BOOK_ID VARCHAR(13), " +
                "AUTHOR_NAME VARCHAR(20), " +
                "PRIMARY KEY(BOOK_ID, AUTHOR_NAME), " +
                "FOREIGN KEY(BOOK_ID) REFERENCES Book);";

        String createBookCopyTable = "CREATE TABLE Book_Copy( " +
                "BOOK_ID VARCHAR(13), " +
                "BRANCH_ID VARCHAR(5), " +
                "ACCESS_NO VARCHAR(5), " +
                "PRIMARY KEY(ACCESS_NO, BRANCH_ID), " +
                "FOREIGN KEY(BOOK_ID) REFERENCES Book, " +
                "FOREIGN KEY(BRANCH_ID) REFERENCES Branch);";

        String createBranchTable = "CREATE TABLE Branch( " +
                "BRANCH_ID VARCHAR(5), " +
                "BRANCH_NAME VARCHAR(20), " +
                "ADDRESS VARCHAR(30), " +
                "PRIMARY KEY (BRANCH_ID));";

        String createMemberTable = "CREATE TABLE Member( " +
                "MEMBER_ID VARCHAR(5), " +
                "MEMBER_NAME VARCHAR(20), " +
                "ADDRESS VARCHAR(30), " +
                "PHONE VARCHAR(10), " +
                "UNPAID_DUES REAL, " +   // Changed the data type to REAL
                "PRIMARY KEY (MEMBER_ID));";

        String createBookLoanTable = "CREATE TABLE Book_Loan( " +
                "ACCESS_NO VARCHAR(5), " +
                "BRANCH_ID VARCHAR(5), " +
                "MEMBER_ID VARCHAR(5), " +
                "DATE_OUT DATE, " +
                "DATE_DUE DATE, " +
                "DATE_RETURNED DATE, " +
                "PRIMARY KEY(ACCESS_NO, BRANCH_ID, MEMBER_ID, DATE_OUT), " +
                "FOREIGN KEY(ACCESS_NO, BRANCH_ID) REFERENCES Book_Copy, " +
                "FOREIGN KEY(MEMBER_ID) REFERENCES Member, " +
                "FOREIGN KEY(BRANCH_ID) REFERENCES Branch);";

        db.execSQL(createBookTable);
        db.execSQL(createPublisherTable);
        db.execSQL(createBookAuthorTable);
        db.execSQL(createBookCopyTable);
        db.execSQL(createBranchTable);
        db.execSQL(createMemberTable);
        db.execSQL(createBookLoanTable);

        Log.d("DatabaseHelper", "Tables created successfully.");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Book");
        db.execSQL("DROP TABLE IF EXISTS Publisher");
        db.execSQL("DROP TABLE IF EXISTS Book_Author");
        db.execSQL("DROP TABLE IF EXISTS Book_Copy");
        db.execSQL("DROP TABLE IF EXISTS Branch");
        db.execSQL("DROP TABLE IF EXISTS Member");
        onCreate(db);
    }

    public boolean addBook(String bookId, String title, String publisherName, String authorName, String branchId, String accessNo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valuesBook = new ContentValues();
        valuesBook.put("BOOK_ID", bookId);
        valuesBook.put("TITLE", title);
        valuesBook.put("PUBLISHER_NAME", publisherName);
        long bookResult = db.insert("Book", null, valuesBook);

        ContentValues valuesAuthor = new ContentValues();
        valuesAuthor.put("BOOK_ID", bookId);
        valuesAuthor.put("AUTHOR_NAME", authorName);
        long authorResult = db.insert("Book_Author", null, valuesAuthor);

        ContentValues valuesCopy = new ContentValues();
        valuesCopy.put("BOOK_ID", bookId);
        valuesCopy.put("BRANCH_ID", branchId);
        valuesCopy.put("ACCESS_NO", accessNo);
        long copyResult = db.insert("Book_Copy", null, valuesCopy);

        db.close();

        return bookResult != -1 && authorResult != -1 && copyResult != -1;
    }

    public boolean addPublisher(String name, String address, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("NAME", name);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        long result = db.insert("Publisher", null, values);
        db.close();
        return result != -1;
    }

    public boolean addBranch(String branchId, String branchName, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", branchId);
        values.put("BRANCH_NAME", branchName);
        values.put("ADDRESS", address);
        long result = db.insert("Branch", null, values);
        db.close();
        return result != -1;
    }

    public boolean addMember(String memberId, String memberName, String address, String phone, double unpaidDues) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("MEMBER_ID", memberId);
        values.put("MEMBER_NAME", memberName);
        values.put("ADDRESS", address);
        values.put("PHONE", phone);
        values.put("UNPAID_DUES", unpaidDues);
        long result = db.insert("Member", null, values);
        db.close();
        return result != -1;
    }

    // Search for a book by ID
    public SearchBookActivity.Book getBookById(String bookId) {
        SQLiteDatabase db = this.getReadableDatabase();
        SearchBookActivity.Book book = null;
        Cursor cursor = db.rawQuery("SELECT * FROM Book WHERE BOOK_ID=?", new String[]{bookId});
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") String title = ((Cursor) cursor).getString(cursor.getColumnIndex("TITLE"));
            @SuppressLint("Range") String publisherName = cursor.getString(cursor.getColumnIndex("PUBLISHER_NAME"));

        }
        cursor.close();
        db.close();
        return book;
    }

    // Check if the book is available in a particular branch
    public boolean isBookAvailable(String bookId, String branchId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Book_Copy WHERE BOOK_ID=? AND BRANCH_ID=?", new String[]{bookId, branchId});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return result;
    }

    // Give loan to a member
    public boolean giveLoan(String accessNo, String branchId, String memberId, String dateOut, String dateDue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ACCESS_NO", accessNo);
        values.put("BRANCH_ID", branchId);
        values.put("MEMBER_ID", memberId);
        values.put("DATE_OUT", dateOut);
        values.put("DATE_DUE", dateDue);
        long result = db.insert("Book_Loan", null, values);
        db.close();
        return result != -1;
    }

    // Get the current date in the format "YYYY-MM-DD"


    // Get the due date by adding 14 days to the current date


    public void giveLoan(String bookId, String branchId, String memberId) {
    }
}



